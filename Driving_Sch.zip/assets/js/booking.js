document.addEventListener("DOMContentLoaded", function () {
    console.log("Booking.js loaded!"); // Debugging

    const form = document.getElementById("booking-form");
    if (!form) {
        console.error("Form not found!");
        return;
    }

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // 🔥 Stop form from submitting normally
        console.log("Redirecting to payment.html..."); // Debugging

        window.location.href = "payment.html";
    });
});

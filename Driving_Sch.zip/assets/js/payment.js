document.addEventListener("DOMContentLoaded", function () {
    // Get URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const course = urlParams.get("course");
    const price = urlParams.get("price");

    // Populate the payment form fields
    if (course) document.getElementById("course").value = course;
    if (price) document.getElementById("price").value = price;

    const paymentOption = document.querySelector("#payment-option");
    const installmentInfo = document.querySelector("#installment-info");
    const installmentAmount = document.querySelector("#installment-amount");
    const priceInput = document.querySelector("#price");

    if (!paymentOption || !installmentInfo || !installmentAmount || !priceInput) {
        console.error("Some elements are missing in the DOM.");
        return;
    }

    // Function to update installment details
    paymentOption.addEventListener("change", function () {
        if (this.value === "installment" && price) {
            installmentInfo.style.display = "block";
            installmentAmount.value = (parseFloat(price) / 2).toFixed(2);
        } else {
            installmentInfo.style.display = "none";
            installmentAmount.value = "";
        }
    });

    // Trigger change event initially
    paymentOption.dispatchEvent(new Event("change"));
});

document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector(".form-box.login form");
    const registerForm = document.querySelector(".form-box.register form");
    const registerBtn = document.querySelector(".register-btn");
    const loginBtn = document.querySelector(".login-btn");
    const container = document.querySelector(".container");

    const nameInput = document.querySelector(".form-box.register input[placeholder='Username']");
    const emailInput = document.querySelector(".form-box.register input[placeholder='Email']");
    const pwInput = document.querySelector(".form-box.register input[placeholder='Password']");

    const userName = document.querySelector(".form-box.login input[placeholder='Username']");
    const userPw = document.querySelector(".form-box.login input[placeholder='Password']");

   
    registerBtn.addEventListener("click", function () {
        container.classList.add("active");
    });

    loginBtn.addEventListener("click", function () {
        container.classList.remove("active");
    });

    
    registerForm.addEventListener("submit", function (e) {
        e.preventDefault();
        if (nameInput.value && pwInput.value) {
            localStorage.setItem("name", nameInput.value);
            localStorage.setItem("email", emailInput.value);
            localStorage.setItem("pw", pwInput.value);
            alert("Registration successful! You can now log in.");
            nameInput.value = "";
            emailInput.value = "";
            pwInput.value = "";
        } else {
            alert("Please fill in all fields.");
        }
    });

   
    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();
        var storedName = localStorage.getItem("name");
        var storedPw = localStorage.getItem("pw");
    
        if (userName.value === storedName && userPw.value === storedPw) {
            alert("You are logged in.");
            localStorage.setItem("isLoggedIn", "true"); // Store login state
            localStorage.setItem("loggedInUser", storedName); // Store username
            window.location.href = "index.html"; // Redirect to homepage or any page
        } else {
            alert("ERROR: Incorrect username or password.");
        }
    });
});

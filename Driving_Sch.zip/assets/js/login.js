document.addEventListener("DOMContentLoaded", function () {
    const loginBtns = document.querySelectorAll("#login-btn");
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    if (isLoggedIn === "true") {
        const username = localStorage.getItem("loggedInUser") || "User";
        loginBtns.forEach(loginBtn => {
            loginBtn.textContent = username;
            loginBtn.href = "#";
            loginBtn.style.pointerEvents = "auto";
            loginBtn.classList.add("dropdown-toggle");

            // Create dropdown menu
            const dropdownMenu = document.createElement("div");
            dropdownMenu.classList.add("dropdown-menu");
            dropdownMenu.innerHTML = `
                <a href="edit-profile.html" id="edit-profile-btn">Edit Profile</a>
                <a href="#" id="logout-btn">Logout</a>
            `;
            loginBtn.parentNode.appendChild(dropdownMenu);

            // Toggle dropdown
            loginBtn.addEventListener("click", function () {
                dropdownMenu.classList.toggle("show");
            });

            // Logout functionality
            document.getElementById("logout-btn").addEventListener("click", function () {
                localStorage.removeItem("isLoggedIn");
                localStorage.removeItem("loggedInUser");
                window.location.href = "index.html";
            });
        });
    }
});
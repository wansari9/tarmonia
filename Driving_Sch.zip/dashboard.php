<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: dashboardlogin.php");
    exit();
}

include 'db_connection.php'; // Include database connection

// Fetch data from the database
$students_count = $conn->query("SELECT COUNT(*) AS count FROM students")->fetch_assoc()['count'];
$instructors_count = $conn->query("SELECT COUNT(*) AS count FROM instructors")->fetch_assoc()['count'];
$courses_count = $conn->query("SELECT COUNT(*) AS count FROM courses")->fetch_assoc()['count'];
$earnings = $conn->query("SELECT SUM(amount) AS total FROM payments WHERE status = 'paid'")->fetch_assoc()['total'];

// Fetch students nearing completion
$students_nearing_completion = $conn->query("
    SELECT s.first_name, s.last_name, c.course_name, cp.completed_hours, c.duration_hours 
    FROM course_progress cp
    JOIN students s ON cp.student_id = s.student_id
    JOIN courses c ON cp.course_id = c.course_id
    WHERE cp.course_completion_status = 'in_progress'
    ORDER BY cp.completed_hours DESC
");

// Fetch top instructors by revenue
$top_instructors = $conn->query("
    SELECT i.first_name, i.last_name, SUM(p.amount) AS revenue
    FROM instructors i
    JOIN schedules sch ON i.instructor_id = sch.instructor_id
    JOIN payments p ON sch.schedule_id = p.schedule_id
    WHERE p.status = 'paid'
    GROUP BY i.instructor_id
    ORDER BY revenue DESC
    LIMIT 5
");

// Fetch students list
$students_result = $conn->query("SELECT * FROM students");

// Fetch instructors list
$instructors_result = $conn->query("SELECT * FROM instructors");

// Fetch courses list
$courses_result = $conn->query("SELECT * FROM courses");

// Fetch schedules list
$schedules_result = $conn->query("SELECT * FROM schedules");

// Fetch payments list with student names
$payments_result = $conn->query("
    SELECT p.*, s.first_name, s.last_name 
    FROM payments p
    JOIN students s ON p.student_id = s.student_id
");

// Fetch schedules data
$schedules = $conn->query("SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_last_name 
                           FROM schedules s
                           JOIN students st ON s.student_id = st.student_id
                           JOIN instructors i ON s.instructor_id = i.instructor_id");
$schedules_data = [];
while ($row = $schedules->fetch_assoc()) {
    $schedules_data[] = $row;
}

// Fetch notifications
$notificationsQuery = "
    SELECT notification_id, message, created_at, is_read
    FROM notifications
    WHERE is_read = 0
    ORDER BY created_at DESC
";
$notificationsResult = $conn->query($notificationsQuery);

// Fetch read notifications
$readNotificationsQuery = "
    SELECT notification_id, message, created_at, is_read
    FROM notifications
    WHERE is_read = 1
    ORDER BY created_at DESC
    LIMIT 10
";
$readNotificationsResult = $conn->query($readNotificationsQuery);

// Mark notifications as read
if (isset($_POST['mark_as_read'])) {
    $markAsReadQuery = "UPDATE notifications SET is_read = 1 WHERE is_read = 0";
    $conn->query($markAsReadQuery);
    $_SESSION['last_mark_as_read'] = time();
    echo json_encode(['success' => true]);
    exit();
}

if (isset($_POST['delete_notifications'])) {
    $notificationIds = json_decode($_POST['notification_ids']);
    $placeholders = implode(',', array_fill(0, count($notificationIds), '?'));
    $deleteQuery = "DELETE FROM notifications WHERE notification_id IN ($placeholders)";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param(str_repeat('i', count($notificationIds)), ...$notificationIds);
    $stmt->execute();
    echo json_encode(['success' => true]);
    exit();
}

if (isset($_POST['mark_selected_as_read'])) {
    $notificationIds = json_decode($_POST['notification_ids']);
    $placeholders = implode(',', array_fill(0, count($notificationIds), '?'));
    $markSelectedAsReadQuery = "UPDATE notifications SET is_read = 1 WHERE notification_id IN ($placeholders)";
    $stmt = $conn->prepare($markSelectedAsReadQuery);
    $stmt->bind_param(str_repeat('i', count($notificationIds)), ...$notificationIds);
    $stmt->execute();
    echo json_encode(['success' => true]);
    exit();
}

if (isset($_POST['delete_all_notifications'])) {
    $deleteType = $_POST['delete_type'];
    $deleteAllQuery = "DELETE FROM notifications WHERE is_read = $deleteType";
    $conn->query($deleteAllQuery);
    echo json_encode(['success' => true]);
    exit();
}

// Fetch schedules near current date
$currentDate = date('Y-m-d');
$nearDate = date('Y-m-d', strtotime('+7 days')); // Adjust the range as needed
$schedules_near_current_date = $conn->query("
    SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_last_name 
    FROM schedules s
    JOIN students st ON s.student_id = st.student_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    WHERE s.start_time BETWEEN '$currentDate' AND '$nearDate'
    ORDER BY s.start_time ASC
    LIMIT 10
");

// Fetch schedules within a week for notifications
$schedules_within_week = $conn->query("
    SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_last_name 
    FROM schedules s
    JOIN students st ON s.student_id = st.student_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    WHERE s.start_time BETWEEN '$currentDate' AND '$nearDate'
    ORDER BY s.start_time ASC
");

// Add schedules within a week to notifications
while ($schedule = $schedules_within_week->fetch_assoc()) {
    $message = "Upcoming schedule: " . $schedule['student_first_name'] . " " . $schedule['student_last_name'] . " with " . $schedule['instructor_first_name'] . " " . $schedule['instructor_last_name'] . " on " . date('M j, g:i A', strtotime($schedule['start_time']));
    addNotification($message, $conn);
}

// Fetch schedules within the next week for the dropdown
$upcoming_week_schedules = $conn->query("
    SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_last_name 
    FROM schedules s
    JOIN students st ON s.student_id = st.student_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    WHERE s.start_time BETWEEN '$currentDate' AND '$nearDate'
    ORDER BY s.start_time ASC
");

// Fetch the next schedule date
$next_schedule = $conn->query("
    SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.first_name AS instructor_first_name 
    FROM schedules s
    JOIN students st ON s.student_id = st.student_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    WHERE s.start_time > '$currentDate'
    ORDER BY s.start_time ASC
    LIMIT 1
")->fetch_assoc();

// Fetch upcoming schedules for the dropdown
$upcoming_schedules = $conn->query("
    SELECT s.*, st.first_name AS student_first_name, st.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_last_name, c.course_name
    FROM schedules s
    JOIN students st ON s.student_id = st.student_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    JOIN courses c ON s.course_id = c.course_id
    WHERE s.start_time > '$currentDate'
    ORDER BY s.start_time ASC
    LIMIT 10
");

// Function to add a notification
function addNotification($message, $conn)
{
    // Check if the notification already exists
    $checkQuery = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE message = ?");
    $checkQuery->bind_param("s", $message);
    $checkQuery->execute();
    $result = $checkQuery->get_result();
    $count = $result->fetch_assoc()['count'];
    $checkQuery->close();

    if ($count == 0) {
        $stmt = $conn->prepare("INSERT INTO notifications (message, created_at, is_read) VALUES (?, NOW(), 0)");
        $stmt->bind_param("s", $message);
        $stmt->execute();
        $stmt->close();
    }
}

// Function to get appointments details
function getAppointmentsDetails($date, $conn)
{
    $query = $conn->prepare("
        SELECT s.first_name AS student_first_name, s.last_name AS student_last_name, i.first_name AS instructor_first_name, i.last_name AS instructor_first_name, sch.start_time, sch.end_time
        FROM schedules sch
        JOIN students s ON sch.student_id = s.student_id
        JOIN instructors i ON sch.instructor_id = i.instructor_id
        WHERE DATE(sch.start_time) = ?
    ");
    $query->bind_param("s", $date);
    $query->execute();
    $result = $query->get_result();
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    $query->close();
    return $appointments;
}

// Fetch appointments for specific dates
$appointments_08Jan2023 = getAppointmentsDetails('2023-01-08', $conn);
$appointments_27Jan2023 = getAppointmentsDetails('2023-01-27', $conn);

// Fetch notifications again after adding new ones
$notificationsResult = $conn->query($notificationsQuery);
$readNotificationsResult = $conn->query($readNotificationsQuery);

// Fetch unread notifications count
$unreadCountQuery = "SELECT COUNT(*) AS unread_count FROM notifications WHERE is_read = 0";
$unreadCountResult = $conn->query($unreadCountQuery);
$unreadCount = $unreadCountResult->fetch_assoc()['unread_count'];

// Fetch attendance data
$student_attendance = $conn->query("SELECT (SUM(attended) / COUNT(*)) * 100 AS avg_attendance FROM attendance WHERE student_id IS NOT NULL")->fetch_assoc()['avg_attendance'];
$teacher_attendance = $conn->query("SELECT (SUM(attended) / COUNT(*)) * 100 AS avg_attendance FROM attendance WHERE instructor_id IS NOT NULL")->fetch_assoc()['avg_attendance'];

// Fetch performance data
$performance_data = $conn->query("
    SELECT s.student_id, s.first_name, s.last_name, p.test_score, p.driving_test_result 
    FROM performance p
    JOIN course_progress cp ON p.progress_id = cp.progress_id
    JOIN students s ON cp.student_id = s.student_id
    ORDER BY p.date_recorded DESC
    LIMIT 11
");

// Fetch revenue vs expenses data
$revenue_expenses_data = $conn->query("
    SELECT DATE_FORMAT(transaction_date, '%Y-%m') AS month, SUM(total_revenue) AS total_revenue, SUM(total_expenses) AS total_expenses
    FROM revenue_vs_expenses
    GROUP BY month
    ORDER BY month DESC
    LIMIT 12
");

$months = [];
$total_revenues = [];
$total_expenses = [];

// Initialize all months with zero values
$month_names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
foreach ($month_names as $month_name) {
    $months[$month_name] = ['total_revenue' => 0, 'total_expenses' => 0];
}

while ($row = $revenue_expenses_data->fetch_assoc()) {
    $month_name = date('F', strtotime($row['month'] . '-01'));
    $months[$month_name] = [
        'total_revenue' => $row['total_revenue'],
        'total_expenses' => $row['total_expenses']
    ];
}

$month_labels = array_keys($months);
$total_revenues = array_column($months, 'total_revenue');
$total_expenses = array_column($months, 'total_expenses');

$total_earnings = array_sum($total_revenues);

// Fetch attendance data
$student_attendance_data = $conn->query("
    SELECT gender, SUM(attended) AS attended_count, COUNT(*) AS total_count 
    FROM attendance 
    JOIN students ON attendance.student_id = students.student_id 
    GROUP BY gender
")->fetch_all(MYSQLI_ASSOC);

$male_attendance = 0;
$female_attendance = 0;
$total_attendance = 0;

foreach ($student_attendance_data as $data) {
    if ($data['gender'] == 'male') {
        $male_attendance = ($data['attended_count'] / $data['total_count']) * 100;
    } elseif ($data['gender'] == 'female') {
        $female_attendance = ($data['attended_count'] / $data['total_count']) * 100;
    }
    $total_attendance += $data['attended_count'];
}

$not_attended = 100 - (($total_attendance / array_sum(array_column($student_attendance_data, 'total_count'))) * 100);

// Fetch gender performance data
$gender_performance_data = $conn->query("
    SELECT gender, average_score, pass_count, fail_count 
    FROM gender_performance
")->fetch_all(MYSQLI_ASSOC);

$male_data = ['average_score' => 0, 'pass_rate' => 0, 'fail_rate' => 0];
$female_data = ['average_score' => 0, 'pass_rate' => 0, 'fail_rate' => 0];

foreach ($gender_performance_data as $data) {
    $total_tests = $data['pass_count'] + $data['fail_count'];
    if ($total_tests > 0) {
        $pass_rate = ($data['pass_count'] / $total_tests) * 100;
        $fail_rate = ($data['fail_count'] / $total_tests) * 100;
    } else {
        $pass_rate = 0;
        $fail_rate = 0;
    }
    if ($data['gender'] == 'male') {
        $male_data['average_score'] = $data['average_score'];
        $male_data['pass_rate'] = $pass_rate;
        $male_data['fail_rate'] = $fail_rate;
    } elseif ($data['gender'] == 'female') {
        $female_data['average_score'] = $data['average_score'];
        $female_data['pass_rate'] = $pass_rate;
        $female_data['fail_rate'] = $fail_rate;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarmonia Driving School Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="icon" href="assets/images/new-logo.gif"> <!-- Updated title icon -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Rubik', sans-serif;
        }

        body {
            font-family: 'Rubik', sans-serif;
            background-color: #E8F5E9;
            /* Match main-content background */
            color: #333333;
            display: flex;
            min-height: 100vh;
            overflow: hidden;
            /* Make the whole home page unscrollable */
        }

        .sidebar {
            width: 250px;
            background-color: #121212;
            /* Sidebar Background */
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            color: #E0E0E0;
            /* Sidebar Text */
            display: flex;
            flex-direction: column;
            height: calc(100% - 40px);
            box-sizing: border-box;
            position: fixed;
            transition: background-color 0.4s, color 0.4s;
            margin: 20px;
            border-radius: 10px;
        }

        .sidebar .logo {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 150px;
            height: 150px;
            background-color: #333;
            /* Accent */
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-image: url('../upload/Newlogo.gif');
            background-size: cover;
            background-position: center;
            cursor: pointer;
            margin: 0 auto 20px auto;
        }

        .sidebar h1 {
            font-size: 20px;
            margin-bottom: 30px;
            text-align: center;
            font-weight: 600;
        }

        .sidebar h1 {
            font-size: 20px;
            /* Changed font size */
            margin-bottom: 30px;
            text-align: center;
            font-weight: 600;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar li {
            padding: 15px 20px;
            margin-bottom: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            transition: background-color 0.3s, color 0.3s;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 500;
        }

        .sidebar li.active {
            background-color: #2E7D32;
            /* Green background for active item */
            color: #fff;
        }

        .sidebar li:hover {
            background-color: #E8F5E9;
            /* Light green background on hover */
            color: #2E7D32;
            /* Green text color on hover */
        }

        .sidebar li i {
            font-size: 1.5em;
            text-align: center;
            margin-left: 20px;
        }

        .sidebar li span {
            margin-left: 15px;
        }

        .sidebar .bottom-buttons {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .sidebar .bottom-buttons .settings-btn,
        .sidebar .bottom-buttons .log-out-btn {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            transition: background-color 0.3s, color 0.3s;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 500;
        }

        .sidebar .bottom-buttons .settings-btn:hover,
        .sidebar .bottom-buttons .log-out-btn:hover {
            background-color: #E8F5E9;
            /* Light green background on hover */
            color: #2E7D32;
            /* Green text color on hover */
        }

        .sidebar .bottom-buttons .settings-btn i,
        .sidebar .bottom-buttons .log-out-btn i {
            font-size: 1.5em;
            text-align: center;
            margin-left: 20px;
        }

        .sidebar .bottom-buttons .settings-btn span,
        .sidebar .bottom-buttons .log-out-btn span {
            margin-left: 15px;
        }

        .sidebar-footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #3E5879;
            text-align: center;
            color: #fff;
            font-size: 0.9em;
        }

        .sidebar-footer a {
            color: #fff;
            text-decoration: none;
        }

        .sidebar-footer a:hover {
            color: #DCA854;
            text-decoration: none;
        }

        /* Responsive adjustments for the sidebar */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                /* Full width on small screens */
                position: static;
                /* Remove fixed positioning */
                height: auto;
                /* Auto height */
            }
        }

        /* --- Main Content --- */
        .main-content {
            flex: 1;
            padding: 20px;
            margin-left: 250px;
            margin-top: 80px;
            /* Adjust margin-top to account for fixed top-bar */
            background-color: #E8F5E9;
            /* Light green background */
            overflow-y: auto;
            /* Make other pages scrollable */
        }

        /* --- General Page Styles --- */
        .page-content {
            display: none;
            /*Hide all pages by default */
            margin-left: 20px;
            /* Move page-content 10px to the right */
            overflow-y: hidden;
            /* Hide overflow for non-active pages */
        }

        .page-content.active-page {
            display: block;
            /* Show the active page */
            overflow-y: auto;
            /* Make other pages scrollable */
            max-height: calc(100vh - 100px);
            /* Ensure the page content does not exceed the viewport height */
        }

        .page-content h1 {
            font-size: 20px;
            /* Changed font size */
            font-weight: bold;
            color: #1a1a1a;
            /* Dark heading */
            margin-bottom: 20px;
        }

        .page-content .content-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            /* Space between containers - KEY for even spacing */
            overflow-y: auto;
            /* Allow scrolling within content containers */
        }

        .page-content .content-container h2 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #2E7D32;
            /* Green heading color */
        }

        /* Add this CSS to set the max height of the chart container */
        #genderPerformanceChart {
            max-height: 400px;
            height: 400px;
            /* Ensure the container has a fixed height */
        }

        /* --- Table Styles --- */
        .page-content table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            /* Space below tables */
        }

        .page-content th,
        .page-content td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        .page-content th.id-column,
        .page-content td.id-column,
        .page-content th.method-column,
        .page-content td.method-column {
            text-align: center;
        }

        .page-content th.name-column,
        .page-content td.name-column {
            text-align: left;
        }

        .page-content td button {
            padding: 5px 10px;
            margin-right: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .page-content button {
            padding: 8px 16px;
            border-radius: 5px;
            background-color: #2E7D32;
            /* Green background */
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .page-content td button:hover,
        .page-content button:hover {
            background-color: #1B5E20;
            /* Darker green on hover */
            color: white;
        }

        .page-content td .action-icon {
            font-size: 1.5em;
            cursor: pointer;
            margin-right: 10px;
            transition: color 0.2s;
        }

        .page-content td .action-icon:hover {
            color: #1B5E20;
            /* Darker green on hover */
        }

        /* --- Specific Page Content Overrides --- */

        /* Dashboard Page Overrides */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            /* Consistent bottom margin */
            position: fixed;
            /* Make the top-bar fixed */
            top: 20px;
            /* Align with the sidebar's top margin */
            right: 20px;
            /* Add the same margin from the right */
            left: 290px;
            /* Add margin to the left to align with content-left */
            width: calc(100% - 310px);
            /* Adjust width to account for sidebar and margins */
            background-color: #fff;
            /* Match the container background color */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            /* Add box-shadow for container effect */
            z-index: 1000;
            padding: 10px 20px;
            /* Add padding to avoid content overlap */
            border-radius: 10px;
            /* Match the border-radius of other containers */
            gap: 20px;
            /* Add gap between elements */
        }

        .top-bar .welcome-message {
            flex: 1;
            text-align: left;
            /* Align text to the left */
            display: flex;
            align-items: center;
            /* Center vertically */
        }

        .top-bar .search-bar {
            flex: 2;
            display: flex;
            justify-content: center;
        }

        .top-bar .account-info {
            flex: 1;
            text-align: right;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 10px;
        }

        .account-info .notification-icon {
            font-size: 1.5em;
            cursor: pointer;
        }

        .account-info .profile-picture {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ddd;
            /* Placeholder color */
            background-image: url('../upload/profile.jpg');
            /* Replace with actual profile picture URL */
            background-size: cover;
            background-position: center;
        }

        .content-top {
            display: grid;
            grid-column: span 2;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .content-body {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
        }

        .content-left {
            display: grid;
            grid-template-columns: 3fr 2fr;
            gap: 20px;
            align-items: start;
        }

        .card.total-earnings {
            width: 100%;
            height: 300px;
            grid-column: span 2;
        }

        .card.student-performances {
            width: 100%;
            height: 335px;
            margin-bottom: 20px;
            grid-column: 1 / span 1;
        }

        .card.attendance-percentage {
            width: 100%;
            height: 335px;
            margin-bottom: 20px;
            grid-column: 2 / span 1;
        }

        .card.students-nearing-completion {
            height: 290px;
        }


        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: relative;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #2E7D32;
            /* Green heading color */
            font-weight: 600;
        }

        .card p {
            font-size: 2em;
            font-weight: bold;
            color: #212121;
            /* Dark text color */
        }

        .card .card-icon {
            float: right;
            font-size: 3rem;
            color: #2E7D32;
            /* Green icon color */
        }

        .card.top-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            /* Space between text and icon */
        }

        .card.top-row i {
            font-size: 3em;
            color: #2E7D32;
            /* Green icon color */
            margin-left: 20px;
            /* Spacing between text and icon */
        }

        .top-performer table {
            width: 100%;
            border-collapse: collapse;
        }

        .top-performer table th,
        .top-performer table td {
            padding: 10px;
            /* More padding */
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        .top-performer table .image-name {
            display: flex;
            align-items: center;
        }

        .top-performer table .image-name img {
            height: 30px;
            width: 30px;
            border-radius: 50%;
            margin-right: 5px;
        }

        .top-performer table .top-performer-rank {
            background-color: red;
            color: white;
            display: inline-block;
            padding: 2px 5px;
            border-radius: 3px;
        }

        .top-performer table th {
            font-weight: 600;
            color: #555;
        }

        .top-performer table td:nth-child(1) {
            /* Profile Picture Column */
            width: 40px;
        }

        .top-performer table td:nth-child(2) {
            /* Name Column */
            font-weight: 500;
            /* Slightly bolder names */
        }

        .top-performer table td:nth-child(4) {
            /* Rank Column */
            color: #e74c3c;
            /* Red rank */
            font-weight: bold;
        }

        .top-performer .profile-pic {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #ddd;
            /* Placeholder color */
            margin-right: 10px;
            display: inline-block;
            vertical-align: middle;
        }

        .attendance-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background-color: #E8F5E9;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
        }

        .attendance-circle p {
            text-align: center;
            font-size: 1.5em;
            color: #2E7D32;
        }

        .attendance-text {
            text-align: center;
            margin-top: 10px;
        }

        .attendance-text div {
            display: inline-block;
            margin: 0 5px;
        }

        .appointment-details {
            display: none;
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
            z-index: 10;
            width: 200px;
            text-align: left;
        }

        @media (max-width: 1200px) {
            .content-top {
                grid-template-columns: repeat(2, 1fr);
                /* Two columns */
            }

            .content-right {
                grid-template-columns: 1fr;
                /* One columns */
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
                /* Stack sidebar and content */
            }

            .sidebar {
                width: 100%;
                margin-bottom: 20px;
                position: static;
                /* Remove fixed*/
                height: auto;
            }

            .content-top,
            .content-left,
            .content-right {
                grid-template-columns: 1fr;
                /* Single column layout */
            }

            .search-bar input {
                width: 100%;
            }

            .main-content {
                margin-left: 0;
            }

            .content-body {
                grid-template-columns: 1fr;
                /* Reset to single column */
            }
        }

        .content-right .card {
            margin-bottom: 20px;
        }

        .logo-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .logo-separator {
            width: 80%;
            border: 0;
            border-top: 2px solid #fff;
            margin: 0 0 20px 0;
            /* Move the separator higher by 20px */
            opacity: 0.5;
            /* Add some transparency */
        }

        .search-bar {
            position: relative;
            width: 100%;
            max-width: 420px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 40px 10px 20px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 1em;
            outline: none;
            transition: border-color 0.3s;
        }

        .search-bar input:focus {
            border-color: #2E7D32;
        }

        .search-bar i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            font-size: 1.2em;
        }

        .revenue-card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }

        .revenue-card h2 {
            margin-bottom: 5px;
            /* Smaller margin */
        }

        .revenue-card p {
            font-size: 1.5em;
            /* Smaller font size */
            margin-bottom: 5px;
            /* Space for trend icon */
        }

        .revenue-card .trend-icon {
            font-size: 1.2em;
            color: #2E7D32;
            /* Default to green */
        }

        .instructor-table,
        .student-table {
            width: 100%;
            border-collapse: collapse;
        }

        .instructor-table th,
        .instructor-table td,
        .student-table th,
        .student-table td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        .instructor-table th,
        .student-table th {
            font-weight: 600;
            color: #555;
        }

        .instructor-table .profile-pic,
        .student-table .profile-pic {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 8px;
            vertical-align: middle;
        }

        .upcoming-bookings ul {
            list-style: none;
            padding: 0;
        }

        .upcoming-bookings li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }

        .upcoming-bookings li:last-child {
            border-bottom: none;
        }

        .upcoming-bookings li strong {
            margin-right: 5px;
        }

        .instructor-table td,
        .student-table td {
            display: table-cell;
        }

        .instructor-table td img,
        .student-table td img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 5px;
        }

        .instructor-table .image-name,
        .student-table .image-name {
            display: flex;
            align-items: center;
        }

        .instructor-table td:nth-child(3) {
            color: #e74c3c;
            font-weight: bold;
        }

        .card.total-earnings .chart {
            padding: 25px;
            padding-bottom: 50px;
            padding-top: 5px;
            height: 100%;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 90%;
            /* Increased width */
            max-width: 800px;
            /* Increased max-width */
            height: 90%;
            /* Increased height */
            max-height: 600px;
            /* Increased max-height */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            display: flex;
            align-items: center;
            animation-duration: 0.3s;
            /* Adjusted animation duration */
        }

        .side-panel {
            width: 50%;
            padding: 20px;
            border-right: 1px solid #ddd;
            box-sizing: border-box;
        }

        .side-panel img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .modal-main-content {
            width: 70%;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .content-section {
            margin-bottom: 20px;
            margin-top: 20px;
        }

        .close {
            color: #E8F5E9;
            background-color: #1B5E20;
            position: absolute;
            top: -10px;
            right: -30px;
            font-size: 28px;
            font-weight: bold;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
        }

        .close::after {
            content: '';
            position: absolute;
            top: 40px;
            left: 10px;
            width: 0;
            height: 0;
            border-left: 20px solid #2E7D32;
            border-bottom: 20px solid transparent;
        }

        .close:hover,
        .close:focus {
            color: red;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-page {
            display: none;
        }

        .modal-page.active {
            display: block;
        }

        .arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            cursor: pointer;
        }

        .arrow.left {
            left: 10px;
        }

        .arrow.right {
            right: 10px;
        }

        .top-bar .welcome-message h1 {
            font-size: 20px;
            margin-bottom: 0px;
        }

        .top-bar .calendar-header h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .card.students-nearing-completion h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .card.top-instructors h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .card.events-calendar h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .card.upcoming-bookings h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .modal-content h2 {
            font-size: 20px;
            /* Changed font size */
        }

        .page-content button,
        .page-content td button,
        .sidebar .bottom-buttons .settings-btn,
        .sidebar .bottom-buttons .log-out-btn,
        .confirmButton,
        .cancelButton,
        .notification-buttons button {
            font-family: 'Rubik', sans-serif;
            /* Ensure Rubik font is applied to all buttons */
        }

        .appointment-details {
            display: none;
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
            z-index: 10;
            width: 200px;
            text-align: left;
        }

        .notification-bell {
            position: relative;
            cursor: pointer;
        }

        .notification-bell:hover i {
            font-family: 'RemixIcon';
            content: '\e8b2';
            /* Unicode for filled notification icon */
        }

        .notification-count {
            position: absolute;
            top: -10px;
            /* Adjusted position */
            right: -10px;
            /* Adjusted position */
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 5px;
            font-size: 12px;
        }

        .notifications-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #fff;
            border: 1px solid #2E7D32;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 500px;
            z-index: 10;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease;
        }

        .notifications-dropdown.show {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        .notification-tabs {
            display: flex;
            border-bottom: 1px solid #2E7D32;
            /* Green border */
        }

        .notification-tab {
            flex: 1;
            padding: 10px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
            color: #2E7D32;
            /* Green text */
            background-color: #fff;
            /* White background */
        }

        .notification-tab.active {
            background-color: #2E7D32;
            /* Green background for active tab */
            color: white;
        }

        .notification-content {
            display: none;
            max-height: 300px;
            overflow-y: auto;
            background-color: #fff;
            /* White background */
        }

        .notification-content.active {
            display: block;
        }

        .notification-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            /* Light grey border */
            display: flex;
            align-items: center;
            color: #212121;
            /* Dark text color */
            background-color: #fff;
            /* White background */
        }

        .notification-item.unread {
            background-color: #E8F5E9;
            /* Light green background for unread */
        }

        .notification-item.read {
            background-color: #fff;
            /* White background for read */
        }

        .notification-message {
            flex: 1;
            margin-left: 10px;
            margin-right: 10px;
            /* Add margin-right for gap */
        }

        .notification-time {
            font-size: 12px;
            color: #888;
            /* Grey for time */
        }

        .notification-buttons {
            display: flex;
            flex-wrap: wrap;
        }

        .notification-buttons button {
            flex: 1 1 50%;
            padding: 5px;
            border: none;
            background-color: #2E7D32;
            /* Green background */
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
            margin: 0;
            /* Remove margin */
            border-radius: 0;
            /* Remove border-radius */
            font-size: 0.9em;
        }

        .notification-buttons button:hover {
            background-color: #1B5E20;
            /* Even darker green on hover */
        }

        .search-container {
            position: relative;
            width: 100%;
            max-width: 420px;
        }

        .search-container input[type="search"] {
            width: 100%;
            padding: 10px 40px 10px 20px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 1em;
            outline: none;
            transition: border-color 0.3s;
            background-color: #fff;
            color: #212121;
        }

        .search-container input[type="search"]:focus {
            border-color: #2E7D32;
        }

        .search-container .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            font-size: 1.2em;
        }

        .search-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            border-radius: 5px;
            overflow: hidden;
            max-height: 300px;
            overflow-y: auto;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease;
        }

        .search-dropdown.show {
            opacity: 1;
            transform: translateY(0);
        }

        .search-dropdown div {
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .search-dropdown div:hover {
            background-color: #E8F5E9;
        }

        .search-dropdown div span {
            font-weight: bold;
            color: #2E7D32;
        }

        .search-dropdown div small {
            display: block;
            color: #888;
            margin-top: 5px;
        }

        .notification-icon i.ri-notification-2-line:hover {
            color: #2E7D32;
        }

        .notification-icon i.ri-notification-2-fill {
            color: #2E7D32;
        }

        .notification-icon {
            color: #000;
        }

        .notification-checkbox {
            appearance: none;
            width: 20px;
            height: 20px;
            border: 2px solid #2E7D32;
            border-radius: 4px;
            outline: none;
            cursor: pointer;
            position: relative;
            margin-right: 10px;
        }

        .notification-checkbox:checked {
            background-color: #2E7D32;
        }

        .notification-checkbox:checked::after {
            content: '\2714';
            font-size: 16px;
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .appointment-details {
            display: none;
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
            z-index: 10;
            width: 200px;
            text-align: left;
        }

        .instructors-attendance-container {
            display: flex;
            gap: 20px;
        }

        .student-performances tbody,
        .student-table tbody {
            display: block;
            max-height: 250px;
            overflow-y: auto;
        }

        .student-performances thead,
        .student-performances tbody tr,
        .student-table thead,
        .student-table tbody tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .student-performances thead,
        .student-table thead {
            width: calc(100% - 1em);
        }

        .student-performances tbody tr,
        .student-table tbody tr {
            width: 100%;
        }

        .student-performances thead,
        .student-table thead {
            width: 100%;
            /* Change width to 100% */
        }

        #calendar-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            margin: 0px;
            background-color: #2E7D32;
            color: white;
        }

        #calendar table {
            width: 100%;
            border-collapse: collapse;
        }

        #calendar th,
        #calendar td {
            text-align: center;
            padding: 10px;
            border: 1px solid #ddd;
        }

        #calendar td.calendar-date {
            cursor: pointer;
        }

        #calendar td.calendar-date.selected {
            background-color: #2f7ce4;
            /* Highlight color */
            color: white;
        }

        .calendar-date.current-date {
            background-color: #FF7043;
            /* Same orange as the attendance chart */
            color: white;
        }

        .calendar-date.has-appointment {
            background-color: green;
            color: white;
        }

        .table {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
            border-collapse: collapse;
            /* Important for consistent borders */
        }

        .table-bordered th,
        .table-bordered td {
            border: 1px solid #dee2e6;
        }

        .calendar-legend {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .legend-box {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            padding: 10px;
            border: 1px solid #2E7D32;
            border-radius: 5px;
            background-color: #E8F5E9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
            position: relative;
            width: 100%;
            /* Match the width of the calendar */
        }

        .legend-box .legend-header {
            display: flex;
            align-items: center;
            gap: 5px;
            /* Add some space between the circle and the text */
        }

        .legend-color {
            width: 15px;
            height: 15px;
            border-radius: 50%;
        }

        .legend-text {
            font-weight: bold;
        }

        .legend-description {
            color: #888;
            margin-top: 5px;
        }

        .legend-box .arrow {
            position: absolute;
            top: 15px;
            right: 5px;
            cursor: pointer;
            font-size: 1.2em;
            color: #888;
            transition: transform 0.3s ease, color 0.3s ease;
            user-select: none;
            /* Make the arrow un-highlightable */
        }

        .legend-box .arrow.active {
            transform: rotate(90deg);
            transform-origin: center;
        }

        .legend-box .arrow:hover {
            color: #2E7D32;
            /* Change color on hover */
        }

        .legend-box .dropdown {
            display: block;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #fff;
            border: 1px solid #2E7D32;
            /* Match the theme */
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
            z-index: 10;
            width: 100%;
            text-align: left;
            margin-top: -20px;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.5s ease, transform 0.5s ease;
            visibility: hidden;
            color: #333;
            /* Match the theme */
        }

        .legend-box .dropdown.show {
            opacity: 1;
            transform: translateY(0);
            visibility: visible;
        }

        .legend-box .dropdown.hide {
            opacity: 0;
            transform: translateY(-10px);
            visibility: hidden;
        }

        .dropdown-divider {
            height: 1px;
            margin: 10px 0;
            overflow: hidden;
            background-color: #e9ecef;
        }

        .status-paid {
            color: green;
            font-weight: bold;
        }

        .status-unpaid {
            color: red;
            font-weight: bold;
        }

        .student-card .profile-pic {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 20px;
        }

        .student-card .student-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
            color: #2E7D32;
        }

        .student-card .student-info p {
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        .student-cards-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .student-card {
            display: flex;
            align-items: center;
            background-color: #E8F5E9;
            border-radius: 15px;
            border: 1px solid #2E7D32;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
            position: relative;
            overflow: hidden;
            margin-bottom: 20px;
        }

        .student-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100%;
            background-color: #2E7D32;
            clip-path: polygon(100% 0, 0 0, 100% 100%);
        }

        .student-card .profile-pic {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-right: 20px;
            border: 3px solid #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .student-card .student-info {
            flex: 1;
        }

        .student-card .student-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
            color: #333;
        }

        .student-card .student-info p {
            font-size: 14px;
            margin-bottom: 5px;
            color: #666;
        }

        .student-card .menu-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 24px;
            color: #E8F5E9;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
        }

        .student-card .menu-icon:hover {
            transform: scale(1.2);
        }

        .student-card .menu-icon.active {
            transform: rotate(90deg);
        }

        @media (max-width: 768px) {
            .student-cards-container {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .student-cards-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .student-cards-container {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .student-cards-container {
                grid-template-columns: 1fr;
            }
        }

        .edit-icon:hover {
            color: #2E7D32 !important;
            /* Green color on hover */
            cursor: pointer;
        }

        .ri-check-line:hover {
            color: #2E7D32 !important;
            /* Green color on hover */
            cursor: pointer;
        }
    </style>
</head>

<body>


    <aside class="sidebar">
        <div class="logo-container">
            <div class="logo" onclick="showPage('dashboard')"
                style="background-image: url('assets/images/new-logo.gif');">
            </div>
            <hr class="logo-separator">
        </div>
        <ul>
            <!-- Use Remix Icons throughout -->
            <li class="active" data-page="dashboard"><i class="ri-dashboard-line"></i> <span>Dashboard</span></li>
            <li data-page="students"><i class="ri-graduation-cap-line"></i> <span>Students</span></li>
            <!-- Changed icon -->
            <li data-page="instructors"><i class="ri-presentation-line"></i> <span>Instructors</span></li>
            <li data-page="courses"><i class="ri-book-open-line"></i> <span>Courses</span></li>
            <li data-page="schedule"><i class="ri-calendar-2-line"></i> <span>Schedule</span></li>
            <li data-page="payment"><i class="ri-money-dollar-box-line"></i> <span>Payment</span></li>
        </ul>
        <div class="bottom-buttons">
            <!-- Settings and Log Out with Remix Icons -->
            <div class="settings-btn" data-page="settings">
                <i class="ri-settings-2-line"></i>
                <span>Settings</span>
            </div>
            <div class="log-out-btn" onclick="logout()">
                <i class="ri-logout-box-line"></i>
                <span>Log Out</span>
            </div>
        </div>
    </aside>

    <main class="main-content">
        <!-- Move the top-bar here -->
        <div class="top-bar">
            <div class="welcome-message">
                <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
            </div>
            <div class="search-container">
                <input type="search" placeholder="Search...">
                <i class="ri-search-line search-icon"></i>
                <div class="search-dropdown"></div>
            </div>
            <div class="account-info">
                <!-- Notification and Profile Picture -->
                <div class="notification-icon notification-bell" onclick="toggleNotifications()">
                    <i class="ri-notification-2-line"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-count"><?php echo $unreadCount; ?></span>
                    <?php endif; ?>
                </div>
                <div class="profile-picture"></div>
                <div class="notifications-dropdown">
                    <div class="notification-tabs">
                        <div class="notification-tab active" onclick="showNotificationTab('unread')">Unread
                        </div>
                        <div class="notification-tab" onclick="showNotificationTab('read')">Read</div>
                    </div>
                    <div id="unread" class="notification-content active">
                        <ul>
                            <?php while ($notification = $notificationsResult->fetch_assoc()): ?>
                                <li class="notification-item unread">
                                    <input type="checkbox" class="notification-checkbox"
                                        value="<?php echo $notification['notification_id']; ?>">
                                    <span class="notification-message">
                                        <?php echo $notification['message']; ?>
                                    </span>
                                    <span class="notification-time"><?php echo $notification['created_at']; ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                    <div id="read" class="notification-content">
                        <ul>
                            <?php while ($notification = $readNotificationsResult->fetch_assoc()): ?>
                                <li class="notification-item read">
                                    <input type="checkbox" class="notification-checkbox"
                                        value="<?php echo $notification['notification_id']; ?>">
                                    <span class="notification-message">
                                        <?php echo $notification['message']; ?>
                                    </span>
                                    <span class="notification-time"><?php echo $notification['created_at']; ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                    <div class="notification-buttons">
                        <button class="mark-as-read" onclick="markNotificationsAsRead(event)">Mark all as
                            read</button>
                        <button class="mark-selected-as-read" onclick="markSelectedNotificationsAsRead(event)">Mark
                            selected as read</button>
                        <button class="delete-selected" onclick="deleteSelectedNotifications(event)">Delete
                            selected</button>
                        <button class="delete-all" onclick="deleteAllNotifications(event)">Delete all</button>
                        <button class="select-all" onclick="selectAllNotifications(event)">Select all</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Dashboard Page -->
        <div class="page-content active-page" id="dashboard-page">

            <div class="content-body">
                <div class="content-left">
                    <!-- Top Row Cards -->
                    <div class="content-top">
                        <div class="card top-row" style="width: 100%;">
                            <div>
                                <h2>Students</h2>
                                <p>
                                    <?php echo $students_count; ?>
                                </p> <!-- Display real data -->
                            </div>
                            <i class="ri-graduation-cap-line card-icon"></i> <!-- Changed icon -->
                        </div>
                        <div class="card top-row" style="width: 100%;">
                            <div>
                                <h2>Instructors</h2>
                                <p>
                                    <?php echo $instructors_count; ?>
                                </p> <!-- Display real data -->
                            </div>
                            <i class="ri-presentation-line card-icon"></i> <!-- Changed icon -->
                        </div>
                        <div class="card top-row" style="width: 100%;">
                            <div>
                                <h2>Courses</h2>
                                <p>
                                    <?php echo $courses_count; ?>
                                </p> <!-- Display real data -->
                            </div>
                            <i class="ri-book-open-line card-icon"></i>
                        </div>
                        <!-- Removed the earnings card -->
                    </div>
                    <!-- Total Earnings -->
                    <div class="card total-earnings">
                        <h2>Total Earnings <span
                                style="float: right; color: #333;">RM<?php echo number_format($total_earnings, 2); ?></span>
                        </h2>
                        <div class="chart">
                            <canvas id="earningsChart" class="total-earnings-chart"></canvas>
                        </div>
                    </div>
                    <!-- Performance Table -->
                    <div class="card student-performances">
                        <h2>Student Performances</h2>
                        <table class="performance-table">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">ID</th> <!-- Adjusted width -->
                                    <th>Student</th>
                                    <th style="text-align: center;">Score</th>
                                    <th style="text-align: center;">Result</th>
                                </tr>
                            </thead>
                            <tbody style="display: block; max-height: 200px; overflow-y: auto;">
                                <?php while ($performance = $performance_data->fetch_assoc()): ?>
                                    <tr style="display: table; width: 100%; table-layout: fixed;">
                                        <td style="width: 10%;"><?php echo $performance['student_id']; ?></td>
                                        <!-- Adjusted width -->
                                        <td><?php echo $performance['first_name'] . ' ' . $performance['last_name']; ?></td>
                                        <td style="text-align: center;">
                                            <div
                                                style="background-color: red; border-radius: 5px; overflow: hidden; position: relative; color: white;">
                                                <div
                                                    style="width: <?php echo $performance['test_score']; ?>%; background-color: #2E7D32; color: white; padding: 2px 5px; position: absolute; top: 0; left: 0; height: 100%;">
                                                </div>
                                                <span
                                                    style="position: relative; z-index: 1;"><?php echo $performance['test_score']; ?>%</span>
                                            </div>
                                        </td>
                                        <td
                                            style="text-align: center; font-weight: bold; color: <?php echo $performance['driving_test_result'] == 'pass' ? 'green' : 'red'; ?>;">
                                            <?php echo ucfirst($performance['driving_test_result']); ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Attendance Percentage -->
                    <div class="card attendance-percentage">
                        <h2>Attendance Percentage</h2>
                        <div class="chart">
                            <canvas id="attendanceChart" class="attendance-chart"
                                style="width: 300px; height: 250px;"></canvas>
                        </div>
                    </div>
                </div>
                <div class="content-right">
                    <!-- Events Calendar -->
                    <div class="card events-calendar">
                        <div class="calendar-header">
                            <h2>Events Calendar</h2>
                            <div class="calendar-legend">
                                <div class="legend-box">
                                    <div class="legend-header">
                                        <span class="legend-color" style="background-color: #FF7043;"></span>
                                        <span class="legend-text"><?php echo date('d M, Y'); ?></span>
                                    </div>
                                    <span class="legend-description">Current Date</span>
                                    <span class="arrow"
                                        onclick="toggleDropdown('dropdown-current-date', this)">&#9654;</span>
                                    <div id="dropdown-current-date" class="dropdown">
                                        <?php if (empty($appointments_08Jan2023)): ?>
                                            <div>There is no schedule for today</div>
                                        <?php else: ?>
                                            <?php foreach ($appointments_08Jan2023 as $index => $appointment): ?>
                                                <div>
                                                    <strong>Student:</strong>
                                                    <?php echo $appointment['student_first_name'] . ' ' . $appointment['student_last_name']; ?><br>
                                                    <strong>Instructor:</strong>
                                                    <?php echo $appointment['instructor_first_name'] . ' ' . $appointment['instructor_last_name']; ?><br>
                                                    <strong>Time:</strong>
                                                    <?php echo date('g:i A', strtotime($appointment['start_time'])) . ' - ' . date('g:i A', strtotime($appointment['end_time'])); ?><br>
                                                </div>
                                                <?php if ($index < count($appointments_08Jan2023) - 1): ?>
                                                    <div class="dropdown-divider"></div>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="legend-box">
                                    <div class="legend-header">
                                        <span class="legend-color" style="background-color: green;"></span>
                                        <span
                                            class="legend-text"><?php echo date('d M, Y', strtotime($next_schedule['start_time'])); ?></span>
                                    </div>
                                    <span class="legend-description">Upcoming Schedule</span>
                                    <span class="arrow"
                                        onclick="toggleDropdown('dropdown-next-schedule', this)">&#9654;</span>
                                    <div id="dropdown-next-schedule" class="dropdown">
                                        <?php while ($schedule = $upcoming_schedules->fetch_assoc()): ?>
                                            <div>
                                                <strong>Student:</strong>
                                                <?php echo $schedule['student_first_name'] . ' ' . $schedule['student_last_name']; ?><br>
                                                <strong>Course:</strong> <?php echo $schedule['course_name']; ?><br>
                                                <strong>Instructor:</strong>
                                                <?php echo $schedule['instructor_first_name'] . ' ' . $schedule['instructor_last_name']; ?><br>
                                                <strong>Date:</strong>
                                                <?php echo date('M j, Y', strtotime($schedule['start_time'])); ?><br>
                                                <strong>Time:</strong>
                                                <?php echo date('g:i A', strtotime($schedule['start_time'])) . ' - ' . date('g:i A', strtotime($schedule['end_time'])); ?><br>
                                            </div>
                                            <div class="dropdown-divider"></div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="calendar-navigation">
                            <button type="button" id="prev-month">
                                < </button>
                                    <span id="current-month"></span>
                                    <button type="button" id="next-month">></button>
                        </div>
                        <div id="calendar"></div>
                    </div>

                    <!-- Students Progress -->
                    <div class="card students-nearing-completion">
                        <h2>Students Progress</h2>
                        <table class="student-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Course</th>
                                    <th style="text-align: center;">Progress</th>
                                </tr>
                            </thead>
                            <tbody style="display: block; max-height: 160px; overflow-y: auto;">
                                <?php while ($student = $students_nearing_completion->fetch_assoc()): ?>
                                    <tr style="display: table; width: 100%; table-layout: fixed;">
                                        <td><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></td>
                                        <td><?php echo $student['course_name']; ?></td>
                                        <td style="text-align: center;">
                                            <div
                                                style="background-color: red; border-radius: 5px; overflow: hidden; position: relative; color: white;">
                                                <div
                                                    style="width: <?php echo round(($student['completed_hours'] / $student['duration_hours']) * 100, 2); ?>%; background-color: #2E7D32; color: white; padding: 2px 5px; position: absolute; top: 0; left: 0; height: 100%;">
                                                </div>
                                                <span
                                                    style="position: relative; z-index: 1;"><?php echo round(($student['completed_hours'] / $student['duration_hours']) * 100, 2); ?>%</span>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Revenue vs Expenses Chart -->
                </div>
            </div>
        </div>
        </div>


        <!-- Students Page -->
        <div class="page-content" id="students-page">
            <div class="content-container">
                <h2>Students List</h2>
                <div class="student-cards-container">
                    <?php while ($student = $students_result->fetch_assoc()): ?>
                        <div class="student-card">
                            <img src="path/to/profile_pictures/<?php echo $student['profile_picture']; ?>"
                                alt="Profile Picture" class="profile-pic">
                            <div class="student-info">
                                <h3><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h3>
                                <p><?php echo $student['email']; ?></p>
                                <p><?php echo $student['phone_number']; ?></p>
                            </div>
                            <i class="ri-menu-line menu-icon"
                                onclick="openModal(<?php echo $student['student_id']; ?>)"></i>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="content-container">
                <h2>Performance Scores/Rate</h2>
                <canvas id="genderPerformanceChart" style="height: 500px;"></canvas>
            </div>
        </div>

        <!-- Instructors Page -->
        <div class="page-content" id="instructors-page">
            <h1>Instructors</h1>
            <div class="content-container">
                <h2>Instructors List</h2>
                <table>
                    <thead>
                        <tr>
                            <th class="id-column">ID</th>
                            <th class="name-column">Name</th>
                            <th>Email</th>
                            <th>Specialization</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($instructor = $instructors_result->fetch_assoc()): ?>
                            <tr>
                                <td class="id-column">
                                    <?php echo $instructor['instructor_id']; ?>
                                </td>
                                </td>
                                <td>
                                    <?php echo $instructor['email']; ?>
                                </td>
                                <td><?php echo $instructor['specialization']; ?></td>
                                <td>
                                    <i class="ri-edit-line action-icon"
                                        onclick="editItem('instructor', <?php echo $instructor['instructor_id']; ?>)"></i>
                                    <i class="ri-delete-bin-line action-icon"
                                        onclick="deleteItem('instructor', <?php echo $instructor['instructor_id']; ?>)"></i>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Courses Page -->
        <div class="page-content" id="courses-page">
            <h1>Courses </h1>
            <div class="content-container">
                <h2>Course List</h2>
                <table>
                    <thead>
                        <tr>
                            <th class="id-column">ID</th>
                            <th class="name-column">Course Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($course = $courses_result->fetch_assoc()): ?>
                            <tr>
                                <td class="id-column">
                                    <?php echo $course['course_id']; ?>
                                </td>
                                <td class="name-column">
                                    <?php echo $course['course_name']; ?>
                                </td>
                                <td>
                                    <?php echo $course['description']; ?>
                                </td>
                                <td>RM<?php echo number_format($course['price'], 2); ?></td>
                                <td>
                                    <i class="ri-edit-line action-icon"
                                        onclick="editItem('course', <?php echo $course['course_id']; ?>)"></i>
                                    <i class="ri-delete-bin-line action-icon"
                                        onclick="deleteItem('course', <?php echo $course['course_id']; ?>)"></i>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Schedule Page -->
        <div class="page-content" id="schedule-page">
            <h1>Schedule</h1>
            <div class="content-container">
                <h2>Schedule Calendar</h2>
            </div>
        </div>

        <!-- Payment Page -->
        <div class="page-content" id="payment-page">
            <h1>Payments</h1>
            <div class="content-container">
                <h2>Payments List</h2>
                <table>
                    <thead>
                        <tr>
                            <th class="id-column">ID</th>
                            <th class="name-column">Student</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Method</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($payment = $payments_result->fetch_assoc()): ?>
                            <tr>
                                <td class="id-column"><?php echo $payment['payment_id']; ?></td>
                                <td class="name-column"><?php echo $payment['first_name'] . ' ' . $payment['last_name']; ?>
                                </td>
                                <td>RM<?php echo number_format($payment['amount'], 2); ?></td>
                                <td><?php echo $payment['payment_date']; ?></td>
                                <td><?php echo ucwords(str_replace('_', ' ', $payment['payment_method'])); ?></td>
                                <td class="<?php echo $payment['status'] == 'paid' ? 'status-paid' : 'status-unpaid'; ?>">
                                    <?php echo ucfirst($payment['status']); ?>
                                </td>
                                <td>
                                    <i class="ri-edit-line action-icon"
                                        onclick="editItem('payment', <?php echo $payment['payment_id']; ?>)"></i>
                                    <i class="ri-delete-bin-line action-icon"
                                        onclick="deleteItem('payment', <?php echo $payment['payment_id']; ?>)"></i>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Settings Page-->
        <div class="page-content" id="settings-page">
            <h1>Settings</h1>
            <div class="content-container">
                <h2>Settings </h2>
                <p>Manage users, school information, and other settings here.</p>
            </div>
        </div>
    </main>

    <div id="studentDetailsModal" class="modal">
        <div class="modal-content animate__animated animate__zoomIn">
            <span class="close" onclick="closeModal()">&times;</span> <!-- Positioned near the modal box -->
            <div class="side-panel" id="sidePanelContent">
                <!-- Side Panel Content -->
            </div>
            <div class="modal-main-content" id="mainContent">
                <!-- Main Content -->
            </div>
        </div>
    </div>

    <script>
        // Page Switching Logic
        function showPage(pageId) {
            const pages = document.querySelectorAll('.page-content');
            pages.forEach(page => {
                page.classList.remove('active-page');
            });

            document.getElementById(pageId + '-page').classList.add('active-page');

            const sidebarItems = document.querySelectorAll('.sidebar li, .sidebar .settings-btn');
            sidebarItems.forEach(item => {
                item.classList.remove('active');
            });

            const activeItem = document.querySelector(`.sidebar [data-page="${pageId}"]`);
            if (activeItem) {
                activeItem.classList.add('active');
            }

            // Scroll to the top of the main content and the active page content
            document.querySelector('.main-content').scrollTop = 0;
            document.getElementById(pageId + '-page').scrollTop = 0;

            // Store the current active page in localStorage
            localStorage.setItem('activePage', pageId);
        }

        document.addEventListener("DOMContentLoaded", function () {
            const sidebarItems = document.querySelectorAll('.sidebar li, .sidebar .settings-btn');
            sidebarItems.forEach(item => {
                item.addEventListener('click', function () {
                    const pageId = this.dataset.page;
                    showPage(pageId);
                });
            });

            // Load the active page from localStorage or default to 'dashboard'
            const activePage = localStorage.getItem('activePage') || 'dashboard';
            showPage(activePage);

            const urlParams = new URLSearchParams(window.location.search);
            const page = urlParams.get('page');
            if (page) {
                showPage(page);
            } else {
                showPage('dashboard');
            }

            // Get DOM elements
            const calendar = document.getElementById("calendar");
            const currentMonthElement = document.getElementById("current-month");
            const prevMonthButton = document.getElementById("prev-month");
            const nextMonthButton = document.getElementById("next-month");

            // Start with the current date
            const today = new Date();
            let currentMonth = today.getMonth();
            let currentYear = today.getFullYear();

            // Function to generate the calendar grid
            function generateCalendar(month, year) {
                const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                const daysOfWeek = ["S", "M", "T", "W", "T", "F", "S"];

                let calendarHTML = `<table class="table table-bordered"><thead><tr>`;
                // Add day headers (S, M, T, etc.)
                daysOfWeek.forEach(day => {
                    calendarHTML += `<th>${day}</th>`;
                });
                calendarHTML += `</tr></thead><tbody>`;

                // Get the first day of the month
                const firstDay = new Date(year, month, 1).getDay();
                // Get the total number of days in the month
                const daysInMonth = new Date(year, month + 1, 0).getDate();

                let date = 1;
                // Loop through rows (weeks)
                for (let i = 0; i < 6; i++) {
                    calendarHTML += `<tr>`;
                    // Loop through days of the week
                    for (let j = 0; j < 7; j++) {
                        // If it's before the first day of the month, add an empty cell
                        if (i === 0 && j < firstDay) {
                            calendarHTML += `<td></td>`;
                        } else if (date > daysInMonth) {
                            // If we've reached the end of the month, add empty cells
                            calendarHTML += `<td></td>`;
                        } else {
                            // Format the date string (YYYY-MM-DD)
                            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
                            const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

                            // Add the date cell with appropriate classes
                            let cellClass = "calendar-date";
                            if (dateStr === todayStr) {
                                cellClass += " current-date";
                            }
                            if (hasAppointment(year, month, date)) {
                                cellClass += " has-appointment";
                            }

                            calendarHTML += `<td class="${cellClass}" data-date="${dateStr}">${date}</td>`;
                            date++;
                        }
                    }
                    calendarHTML += `<tr>`;
                }
                calendarHTML += `</tbody></table>`;

                // Set the calendar HTML and update the displayed month/year
                calendar.innerHTML = calendarHTML;
                currentMonthElement.textContent = `${months[month]} ${year}`;
            }

            // Remove event listener for clicks on the calendar
            calendar.removeEventListener("click", function (e) {
                // Check if the clicked element is a calendar date cell
                if (e.target.classList.contains("calendar-date")) {
                    // Remove the 'selected' class from all date cells
                    document.querySelectorAll(".calendar-date").forEach(date => {
                        date.classList.remove("selected");
                    });

                    // Add the 'selected' class to the clicked date cell
                    e.target.classList.add("selected");
                    // Get the selected date (you might not need this if you're not doing anything with the selected date)
                    const selectedDate = e.target.getAttribute("data-date");
                }
            });

            // Event listener for the previous month button
            prevMonthButton.addEventListener("click", function () {
                // Prevent going to previous month if already in the current month/year
                if (currentYear === today.getFullYear() && currentMonth === today.getMonth()) {
                    return;
                }

                // Go to the previous month (handling year change if necessary)
                if (currentMonth === 0) {
                    currentMonth = 11;
                    currentYear--;
                } else {
                    currentMonth--;
                }
                // Regenerate the calendar
                generateCalendar(currentMonth, currentYear);
            });

            // Event listener for the next month button
            nextMonthButton.addEventListener("click", function () {
                // Go to the next month (handling year change if necessary)
                if (currentMonth === 11) {
                    currentMonth = 0;
                    currentYear++;
                } else {
                    currentMonth++;
                }
                // Regenerate the calendar
                generateCalendar(currentMonth, currentYear);
            });

            // Initial calendar generation
            generateCalendar(currentMonth, currentYear);
        });

        function hasAppointment(year, month, day) {
            const schedules = <?php echo json_encode($schedules_data); ?>;
            const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            return schedules.some(schedule => schedule.start_time.startsWith(dateString));
        }

        function getAppointmentsDetails(year, month, day) {
            const schedules = <?php echo json_encode($schedules_data); ?>;
            const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const appointments = schedules.filter(schedule => schedule.start_time.startsWith(dateString));
            let details = `<strong>Appointments for ${month + 1}/${day}/${year}:</strong><br>`;
            appointments.forEach(appointment => {
                details += `Student: ${appointment.student_first_name} ${appointment.student_last_name}<br>Instructor: ${appointment.instructor_first_name} ${appointment.instructor_last_name}<br>Course ID: ${appointment.course_id}<br>Start Time: ${appointment.start_time}<br>End Time: ${appointment.end_time}<br><br>`;
            });
            return details;
        }

        function logout() {
            const modal = document.createElement('div');
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
            modal.style.display = 'flex';
            modal.style.justifyContent = 'center';
            modal.style.alignItems = 'center';
            modal.style.zIndex = '1000';

            const modalContent = document.createElement('div');
            modalContent.style.backgroundColor = '#fff';
            modalContent.style.padding = '20px';
            modalContent.style.borderRadius = '10px';
            modalContent.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
            modalContent.style.textAlign = 'center';
            modalContent.style.maxWidth = '400px';
            modalContent.style.width = '100%';

            const message = document.createElement('p');
            message.textContent = 'Are you sure you want to log out?';
            message.style.marginBottom = '20px';
            message.style.fontSize = '18px';
            message.style.color = '#333';

            const buttonContainer = document.createElement('div');
            buttonContainer.style.display = 'flex';
            buttonContainer.style.justifyContent = 'space-around';

            const confirmButton = document.createElement('button');
            confirmButton.textContent = 'Yes';
            confirmButton.classList.add('confirmButton');
            confirmButton.addEventListener('click', function () {
                window.location.href = 'dashboardlogout.php';
            });

            const cancelButton = document.createElement('button');
            cancelButton.textContent = 'No';
            cancelButton.classList.add('cancelButton');
            cancelButton.addEventListener('click', function () {
                document.body.removeChild(modal);
            });

            buttonContainer.appendChild(confirmButton);
            buttonContainer.appendChild(cancelButton);

            modalContent.appendChild(message);
            modalContent.appendChild(buttonContainer);
            modal.appendChild(modalContent);

            document.body.appendChild(modal);
        }

        function capitalizeFirstLetter(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

        function toggleNotifications() {
            const dropdown = document.querySelector('.notifications-dropdown');
            const notificationIcon = document.querySelector('.notification-icon i');
            dropdown.classList.toggle('show');
            if (dropdown.classList.contains('show')) {
                notificationIcon.classList.remove('ri-notification-2-line');
                notificationIcon.classList.add('ri-notification-2-fill');
            } else {
                notificationIcon.classList.remove('ri-notification-2-fill');
                notificationIcon.classList.add('ri-notification-2-line');
            }
        }

        document.addEventListener('click', function (event) {
            const notificationBell = document.querySelector('.notification-bell');
            const dropdown = document.querySelector('.notifications-dropdown');
            if (!notificationBell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
                const notificationIcon = document.querySelector('.notification-icon i');
                notificationIcon.classList.remove('ri-notification-2-fill');
                notificationIcon.classList.add('ri-notification-2-line');
            }
        });

        function showNotificationTab(tab) {
            const tabs = document.querySelectorAll('.notification-tab');
            const contents = document.querySelectorAll('.notification-content');

            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));

            document.querySelector(`.notification-tab[onclick="showNotificationTab('${tab}')"]`).classList.add('active');
            document.getElementById(tab).classList.add('active');
        }

        function markNotificationsAsRead(event) {
            event.stopPropagation();
            event.preventDefault();
            fetch('dashboard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'mark_as_read=1'
            }).then(response => response.json()).then(data => {
                if (data.success) {
                    // Move notifications to the read tab
                    const unreadItems = document.querySelectorAll('.notification-item.unread');
                    const readSection = document.getElementById('read').querySelector('ul');
                    unreadItems.forEach(item => {
                        item.classList.remove('unread');
                        item.classList.add('read');
                        readSection.appendChild(item);
                    });
                    updateUnreadCount();
                }
            });
        }

        function markSelectedNotificationsAsRead(event) {
            event.stopPropagation();
            event.preventDefault();
            const checkboxes = document.querySelectorAll('.notification-checkbox:checked');
            const notificationIds = Array.from(checkboxes).map(checkbox => checkbox.value);

            fetch('dashboard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'mark_selected_as_read=1&notification_ids=' + JSON.stringify(notificationIds)
            }).then(response => response.json()).then(data => {
                if (data.success) {
                    // Move selected notifications to the read tab
                    const readSection = document.getElementById('read').querySelector('ul');
                    checkboxes.forEach(checkbox => {
                        const item = checkbox.closest('.notification-item');
                        item.classList.remove('unread');
                        item.classList.add('read');
                        readSection.appendChild(item);
                        checkbox.checked = false;
                    });
                    updateUnreadCount();
                }
            });
        }

        function deleteSelectedNotifications(event) {
            event.stopPropagation();
            event.preventDefault();
            const checkboxes = document.querySelectorAll('.notification-checkbox:checked');
            const notificationIds = Array.from(checkboxes).map(checkbox => checkbox.value);

            fetch('dashboard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'delete_notifications=1&notification_ids=' + JSON.stringify(notificationIds)
            }).then(response => response.json()).then(data => {
                if (data.success) {
                    // Do not reload the page, instead update the UI
                    checkboxes.forEach(checkbox => {
                        const item = checkbox.closest('.notification-item');
                        item.remove();
                    });
                    updateUnreadCount();
                }
            });
        }

        function deleteAllNotifications(event) {
            event.stopPropagation();
            event.preventDefault();
            const activeTab = document.querySelector('.notification-tab.active').textContent.toLowerCase();
            const deleteType = activeTab === 'unread' ? 0 : 1;

            fetch('dashboard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'delete_all_notifications=1&delete_type=' + deleteType
            }).then(response => response.json()).then(data => {
                if (data.success) {
                    // Remove notifications from the UI
                    document.querySelectorAll(`.notification-item.${activeTab}`).forEach(item => {
                        item.remove();
                    });
                    updateUnreadCount();
                }
            });
        }

        function selectAllNotifications(event) {
            event.stopPropagation();
            event.preventDefault();
            const checkboxes = document.querySelectorAll('.notification-checkbox');
            const selectAllButton = document.querySelector('.select-all');
            const allChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);

            checkboxes.forEach(checkbox => {
                checkbox.checked = !allChecked;
            });

            selectAllButton.textContent = allChecked ? 'Select all' : 'Deselect all';
        }

        function updateUnreadCount() {
            const unreadCount = document.querySelectorAll('.notification-item.unread').length;
            const notificationCountElement = document.querySelector('.notification-count');
            if (unreadCount > 0) {
                notificationCountElement.textContent = unreadCount;
            } else if (notificationCountElement) {
                notificationCountElement.remove();
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const searchInputs = document.querySelectorAll('.search-container input[type="search"]');
            const searchIcons = document.querySelectorAll('.search-icon');

            searchInputs.forEach(searchInput => {
                searchInput.addEventListener('input', function () {
                    const query = this.value.toLowerCase();
                    const dropdown = this.nextElementSibling.nextElementSibling;
                    if (query.length > 0) {
                        const filteredSuggestions = searchSuggestions.filter(item => item.name.toLowerCase().includes(query));
                        dropdown.innerHTML = '';
                        filteredSuggestions.forEach(item => {
                            const div = document.createElement('div');
                            div.innerHTML = `<span>${item.name}</span><small>${item.type}</small>`;
                            div.addEventListener('click', function () {
                                window.location.href = item.url;
                            });
                            dropdown.appendChild(div);
                        });
                        dropdown.classList.add('show');
                    } else {
                        dropdown.innerHTML = '';
                        dropdown.classList.remove('show');
                    }
                });
            });

            searchIcons.forEach(searchIcon => {
                searchIcon.addEventListener('click', function () {
                    const input = this.previousElementSibling;
                    input.focus();
                });
            });
        });

        document.addEventListener("DOMContentLoaded", function () {
            const sidebarItems = document.querySelectorAll('.sidebar li, .sidebar .settings-btn');
            const searchInputs = document.querySelectorAll('.search-container input[type="search"]');
            const searchIcons = document.querySelectorAll('.search-icon');

            sidebarItems.forEach(item => {
                item.addEventListener('click', function () {
                    const pageId = this.dataset.page;
                    showPage(pageId);
                });
            });

            const urlParams = new URLSearchParams(window.location.search);
            const page = urlParams.get('page');
            if (page) {
                showPage(page);
            } else {
                showPage('dashboard');
            }

            searchInputs.forEach(searchInput => {
                searchInput.addEventListener('input', function () {
                    const query = this.value.toLowerCase();
                    const dropdown = document.createElement('div');
                    dropdown.classList.add('search-dropdown');

                    sidebarItems.forEach(item => {
                        const text = item.querySelector('span').textContent.toLowerCase();
                        if (text.includes(query)) {
                            const option = document.createElement('div');
                            option.innerHTML = `<span>${item.querySelector('span').textContent}</span><small>(page)</small>`;
                            option.addEventListener('click', function () {
                                showPage(item.dataset.page);
                                searchInput.value = '';
                                dropdown.remove();
                            });
                            dropdown.appendChild(option);
                        }
                    });

                    const headers = document.querySelectorAll('.page-content h2, .page-content h3');
                    headers.forEach(header => {
                        const text = header.textContent.toLowerCase();
                        if (text.includes(query)) {
                            const pageId = header.closest('.page-content').id.replace('-page', '');
                            const option = document.createElement('div');
                            option.innerHTML = `<span>${header.textContent}</span><small>(container, ${pageId} page)</small>`;
                            option.addEventListener('click', function () {
                                showPage(pageId);
                                searchInput.value = '';
                                dropdown.remove();
                            });
                            dropdown.appendChild(option);
                        }
                    });

                    const existingDropdown = document.querySelector('.search-dropdown');
                    if (existingDropdown) {
                        existingDropdown.remove();
                    }
                    if (query) {
                        searchInput.parentElement.appendChild(dropdown);
                        setTimeout(() => dropdown.classList.add('show'), 10);
                    }
                });
            });

            searchIcons.forEach(searchIcon => {
                searchIcon.addEventListener('click', function () {
                    const searchInput = this.previousElementSibling;
                    searchInput.focus();
                });
            });

            const ctx = document.getElementById('earningsChart').getContext('2d');
            const earningsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($month_labels); ?>,
                    datasets: [{
                        label: 'Revenue',
                        data: <?php echo json_encode($total_revenues); ?>,
                        backgroundColor: '#96FF96',
                        borderColor: '#fff', // White outline
                        borderWidth: 2, // Outline width
                        borderRadius: { topLeft: 10, topRight: 10 },
                        barThickness: 20 // Thicker bars
                    }, {
                        label: 'Expenses',
                        data: <?php echo json_encode($total_expenses); ?>,
                        backgroundColor: '#FF7043',
                        borderColor: '#fff', // White outline
                        borderWidth: 2, // Outline width
                        borderRadius: { topLeft: 10, topRight: 10 },
                        barThickness: 20 // Thicker bars
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            title: {
                                display: false // Remove "Month" label
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#e0e0e0'
                            },
                            title: {
                                display: true,
                                text: 'Amount (RM)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            labels: {
                                pointStyle: 'circle', // Use circle point style
                                usePointStyle: true, // Ensure point style is used
                                font: {
                                    family: 'Rubik, sans-serif' // Use Rubik font
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: '#fff',
                            titleColor: '#000',
                            bodyColor: '#000',
                            borderColor: '#ddd',
                            borderWidth: 1,
                            titleFont: {
                                weight: 'bold',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            bodyFont: {
                                weight: 'normal',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            callbacks: {
                                label: function (context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += 'RM' + context.raw.toLocaleString();
                                    return label;
                                }
                            }
                        }
                    }
                }
            });

            const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
            const attendanceChart = new Chart(attendanceCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Not Attended', 'Male Attendance', 'Female Attendance'],
                    datasets: [{
                        data: [
                            <?php echo $not_attended; ?>,
                            <?php echo $male_attendance; ?>,
                            <?php echo $female_attendance; ?>
                        ],
                        backgroundColor: ['#E0E0E0', '#1E88E5', '#FF69B4'], // Blue for male, Pink for female
                        borderWidth: 1,
                        cutout: '90%' // Make the pie thickness less
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true, // Show legend
                            labels: {
                                pointStyle: 'circle', // Circle point style
                                padding: 20, // Padding around legend items
                                boxWidth: 10, // Box width for legend items
                                boxHeight: 10, // Box height for legend items
                                borderRadius: 5, // Border radius for legend items
                                borderColor: '#fff', // White border color for legend items
                                borderWidth: 2, // Border width for legend items
                                usePointStyle: true, // Use circle point style
                                font: {
                                    family: 'Rubik, sans-serif' // Use Rubik font
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: '#fff',
                            titleColor: '#000',
                            bodyColor: '#000',
                            borderColor: '#ddd',
                            borderWidth: 1,
                            titleFont: {
                                weight: 'bold',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            bodyFont: {
                                weight: 'normal',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            callbacks: {
                                label: function (context) {
                                    let label = context.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += context.raw.toFixed(2) + '%';
                                    return label;
                                }
                            }
                        }
                    }
                }
            });

            const genderPerformanceCtx = document.getElementById('genderPerformanceChart').getContext('2d');
            const genderPerformanceChart = new Chart(genderPerformanceCtx, {
                type: 'bar',
                data: {
                    labels: ['Male', 'Female'],
                    datasets: [
                        {
                            label: 'Average Score',
                            data: [
                                <?php echo $male_data['average_score']; ?>,
                                <?php echo $female_data['average_score']; ?>
                            ],
                            backgroundColor: '#1E88E5',
                            borderColor: '#fff', // White outline
                            borderWidth: 2, // Outline width
                            borderRadius: 10,
                            barThickness: 20
                        },
                        {
                            label: 'Pass Rate (%)',
                            data: [
                                <?php echo $male_data['pass_rate']; ?>,
                                <?php echo $female_data['pass_rate']; ?>
                            ],
                            backgroundColor: '#4CAF50',
                            borderColor: '#fff', // White outline
                            borderWidth: 2, // Outline width
                            borderRadius: 10,
                            barThickness: 20
                        },
                        {
                            label: 'Fail Rate (%)',
                            data: [
                                <?php echo $male_data['fail_rate']; ?>,
                                <?php echo $female_data['fail_rate']; ?>
                            ],
                            backgroundColor: '#FF0000', // Changed to red
                            borderColor: '#fff', // White outline
                            borderWidth: 2, // Outline width
                            borderRadius: 10,
                            barThickness: 20
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            title: {
                                display: false // Remove "Gender" label
                            }
                        },
                        y: {
                            beginAtZero: true,
                            max: 100,
                            grid: {
                                color: '#e0e0e0'
                            },
                            title: {
                                display: true,
                                text: 'Percentage/Score (%)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            labels: {
                                pointStyle: 'circle', // Use circle point style
                                usePointStyle: true, // Ensure point style is used
                                font: {
                                    family: 'Rubik, sans-serif' // Use Rubik font
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: '#fff',
                            titleColor: '#000',
                            bodyColor: '#000',
                            borderColor: '#ddd',
                            borderWidth: 1,
                            titleFont: {
                                weight: 'bold',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            bodyFont: {
                                weight: 'normal',
                                family: 'Rubik, sans-serif' // Use Rubik font
                            },
                            callbacks: {
                                label: function (context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += context.raw.toFixed(2);
                                    return label;
                                }
                            }
                        }
                    }
                }
            });
        });

        function toggleDropdown(dropdownId, arrowElement) {
            const dropdown = document.getElementById(dropdownId);
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
                dropdown.addEventListener('transitionend', function handler() {
                    dropdown.classList.add('hide');
                    dropdown.removeEventListener('transitionend', handler);
                });
            } else {
                dropdown.classList.remove('hide');
                setTimeout(() => {
                    dropdown.classList.add('show');
                }, 10); // Delay to ensure transition works
            }
            arrowElement.classList.toggle('active');
        }

        function openModal(studentId) {
            if (!studentId) {
                console.error('Invalid student ID');
                return;
            }
            console.log('Opening modal for student_id:', studentId); // Log the student_id being passed to the function
            fetch(`get_student_details.php?student_id=${studentId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        data.student_id = studentId; // Ensure student_id is set in the data
                        showStudentDetailsModal(data);
                    } else {
                        console.error('No data returned for student_id:', studentId);
                    }
                })
                .catch(error => {
                    console.error('Error fetching student details:', error);
                });

            // Rotate the menu icon
            const menuIcon = document.querySelector(`.student-card .menu-icon[onclick="openModal(${studentId})"]`);
            if (menuIcon) {
                menuIcon.classList.toggle('active');
            }
        }

        function showStudentDetailsModal(data) {
            const sidePanelContent = `
            <div style="display: flex; flex-direction: column; align-items: center; margin-bottom: 20px; background-color: #2E7D32; padding: 20px; border-radius: 10px;">
                <div style="width: 100px; height: 100px; border-radius: 50%; background-color: #ddd; display: flex; justify-content: center; align-items: center;">
                    <img src="path/to/profile_pictures/${data.profile_picture}" alt="Profile Picture" style="width: 100%; height: 100%; border-radius: 50%;">
                </div>
                <p style="text-align: center; margin-top: 10px; font-weight: bold; color: #fff;"><i class="ri-user-line" style="color: #fff; font-weight: bold;"></i> ${data.first_name} ${data.last_name}</p>
            </div>
            <div id="sidePanelDetails">
                ${generateDetailsHTML(data)}
            </div>
        `;

            const mainContent = `
            <div class="content-section course-progress">
                <h3 style="margin-bottom: 10px;">Course Progress</h3>
                ${generateCourseProgressHTML(data.course_progress)}
            </div>
            <hr>
            <div class="content-section performance">
                <h3 style="margin-bottom: 10px;">Performance</h3>
                ${generatePerformanceHTML(data.performance)}
            </div>
            <hr>
            <div class="content-section payments">
                <h3 style="margin-bottom: 10px;">Payments</h3>
                ${generatePaymentsHTML(data.payments)}
            </div>
            <button onclick="exportDetails(${data.student_id})" style="position: absolute; bottom: 20px; right: 20px; padding: 10px 20px; background-color: #2E7D32; color: white; border: none; border-radius: 5px; cursor: pointer;">Export</button>
        `;

            document.getElementById('sidePanelContent').innerHTML = sidePanelContent;
            document.getElementById('mainContent').innerHTML = mainContent;
            const modal = document.getElementById('studentDetailsModal');
            modal.setAttribute('data-student-id', data.student_id); // Set student_id as a data attribute
            console.log('Setting student_id in modal:', data.student_id); // Log the student_id being set
            modal.style.display = 'flex';
            modal.querySelector('.modal-content').classList.add('animate__zoomIn'); // Add zoom-in animation
        }

        function generateDetailsHTML(data) {
            return `
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-mail-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="email">${data.email}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Email"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-phone-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="phone_number">${data.phone_number}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Phone"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-calendar-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="date_of_birth">${data.date_of_birth}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Date of Birth"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-file-list-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="license_number">${data.license_number}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit License Number"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-calendar-check-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="enrollment_date">${data.enrollment_date}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Enrollment Date"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-map-pin-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="address">${data.address}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Address"></i>
            </div>
            <div style="position: relative; margin-bottom: 10px; color: #333;">
                <p><i class="ri-heart-pulse-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="medical_conditions">${data.medical_conditions ? data.medical_conditions : 'None'}</span></p>
                <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Medical Conditions"></i>
            </div>
            <div style="margin-top: 40px;">
                <h3 style="text-align: center; margin-bottom: 10px; color: #2E7D32;">EMERGENCY</h3>
                <div style="position: relative; margin-bottom: 10px; color: #333;">
                    <p><i class="ri-user-heart-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="emergency_contact_name">${data.emergency_contact_name}</span></p>
                    <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Emergency Contact Name"></i>
                </div>
                <div style="position: relative; margin-bottom: 10px; color: #333;">
                    <p><i class="ri-phone-line" style="color: #2E7D32; font-weight: bold;"></i> <span class="editable" data-field="emergency_contact_phone">${data.emergency_contact_phone}</span></p>
                    <i class="ri-edit-line edit-icon" onclick="editField(this)" style="position: absolute; right: 0; top: 0; color: #aaa; font-weight: bold;" title="Edit Emergency Contact Phone"></i>
                </div>
            </div>
        `;
        }

        function generateCourseProgressHTML(courseProgress) {
            if (courseProgress.length === 0) {
                return '<p>No course registered</p>';
            }

            const options = courseProgress.map((course, index) => `<option value="${index}">${course.course_name} (Attempt ${course.attempt_number || 1})</option>`).join('');
            const progressItems = courseProgress.map((course, index) => `
                <div class="course-progress-item" data-index="${index}" style="${index === 0 ? '' : 'display:none;'}">
                    <p style="margin-bottom: 10px;"><strong>Completed Hours:</strong> ${course.completed_hours}</p>
                    <p style="margin-bottom: 10px;"><strong>Progress:</strong> <div style="background-color: red; border-radius: 5px; overflow: hidden; position: relative; color: white; text-align: center;">
                        <div style="width: ${Math.round((course.completed_hours / course.duration_hours) * 100)}%; background-color: #2E7D32; color: white; padding: 2px 5px; position: absolute; top: 0; left: 0; height: 100%;"></div>
                        <span style="position: relative; z-index: 1;">${Math.round((course.completed_hours / course.duration_hours) * 100)}%</span>
                    </div></p>
                    <p style="margin-top: 10px;"><strong>Retake:</strong> <strong style="color: ${course.attempt_number > 1 ? 'green' : 'red'};">${course.attempt_number > 1 ? 'Yes' : 'No'}</strong></p>
                </div>
            `).join('');

            return `
                <p style="display: inline-block; margin-bottom: 10px;"><strong>Course:</strong></p>
                <select id="courseProgressSelect" onchange="updateCourseProgress()" style="display: inline-block; margin-left: 10px; padding: 5px 10px; border: 1px solid #ddd; border-radius: 5px; background-color: #fff; color: #333; width: 250px;">
                    ${options}
                </select>
                <div id="courseProgressContent">
                    ${progressItems}
                </div>
            `;
        }

        function updateCourseProgress() {
            const select = document.getElementById('courseProgressSelect');
            const selectedIndex = select.value;
            const items = document.querySelectorAll('.course-progress-item');
            items.forEach((item, index) => {
                item.style.display = index == selectedIndex ? '' : 'none';
            });

            // Update the performance section to match the selected course
            const performanceItems = document.querySelectorAll('.performance-item');
            performanceItems.forEach((item, index) => {
                item.style.display = index == selectedIndex ? '' : 'none';
            });
        }

        function generatePerformanceHTML(performance) {
            if (performance.length === 0) {
                return '<p>Performance not yet available</p>';
            }

            const performanceItems = performance.map((perf, index) => `
                <div class="performance-item" data-index="${index}" style="${index === 0 ? '' : 'display:none;'}">
                    <p style="margin-bottom: 10px;"><strong>Test Score:</strong>  
                        <div style="background-color: red; border-radius: 5px; overflow: hidden; position: relative; color: white; text-align: center;">
                            <div style="width: ${perf.test_score}%; background-color: #2E7D32; color: white; padding: 2px 5px; position: absolute; top: 0; left: 0; height: 100%;"></div>
                            <span style="position: relative; z-index: 1;">${perf.test_score}%</span>
                        </div>
                    </p>
                    <p style="margin-top: 10px;"><strong>Driving Test Result:</strong> 
                        <span style="font-weight: bold; color: ${perf.driving_test_result === 'pass' ? 'green' : perf.driving_test_result === 'fail' ? 'red' : 'black'};">
                            ${perf.driving_test_result ? perf.driving_test_result.charAt(0).toUpperCase() + perf.driving_test_result.slice(1) : 'N/A'}
                        </span>
                    </p>
                </div>
            `).join('');

            return `
                <div id="performanceContent">
                    ${performanceItems}
                </div>
            `;
        }

        function generatePaymentsHTML(payments) {
            if (payments.length === 0) {
                return '<p>No payment details available</p>';
            }

            return payments.map(payment => `
            <p style="margin-bottom: 10px;"><strong>Amount:</strong> RM${payment.amount}</p>
            <p style="margin-bottom: 10px;"><strong>Date:</strong> ${payment.payment_date}</p>
            <p style="margin-bottom: 10px;"><strong>Method:</strong> ${payment.payment_method.charAt(0).toUpperCase() + payment.payment_method.slice(1)}</p>
            <p style="margin-bottom: 10px;"><strong>Status:</strong> <strong style="color: ${payment.status === 'paid' ? 'green' : payment.status === 'pending' ? 'yellow' : payment.status === 'refunded' ? 'blue' : 'red'};">${payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}</strong></p>
        `).join('');
        }

        function exportDetails(studentId) {
            fetch(`export_student_details.php?student_id=${studentId}`)
                .then(response => response.blob())
                .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.download = `student_${studentId}_details.csv`;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                })
                .catch(error => console.error('Error exporting details:', error));
        }

        function closeModal() {
            const modal = document.getElementById('studentDetailsModal');
            const modalContent = modal.querySelector('.modal-content');
            modalContent.classList.remove('animate__zoomIn');
            modalContent.classList.add('animate__zoomOut');
            modalContent.addEventListener('animationend', () => {
                modal.style.display = 'none';
                modalContent.classList.remove('animate__zoomOut');

                // Update the student list with the new email and phone number
                const studentId = modal.getAttribute('data-student-id');
                const email = document.querySelector('.editable[data-field="email"]').textContent;
                const phoneNumber = document.querySelector('.editable[data-field="phone_number"]').textContent;

                const studentCard = document.querySelector(`.student-card .menu-icon[onclick="openModal(${studentId})"]`).closest('.student-card');
                studentCard.querySelector('.student-info p:nth-child(2)').textContent = email;
                studentCard.querySelector('.student-info p:nth-child(3)').textContent = phoneNumber;
            }, { once: true });

            // Rotate the menu icon back
            const activeMenuIcon = document.querySelector('.student-card .menu-icon.active');
            if (activeMenuIcon) {
                activeMenuIcon.classList.remove('active');
            }
        }

        // Add event listener to close modal when clicking outside of it
        document.addEventListener('click', function (event) {
            const modal = document.getElementById('studentDetailsModal');
            if (modal.style.display === 'flex' && !modal.contains(event.target) && !event.target.closest('.modal-content')) {
                closeModal();
            }
        });

        // Function to enable editing of fields
        function editField(editIcon) {
            const fieldElement = editIcon.previousElementSibling.querySelector('.editable');
            const fieldName = fieldElement.getAttribute('data-field');
            const currentValue = fieldElement.textContent;

            // Replace the text with an input field
            fieldElement.innerHTML = `<input type="text" value="${currentValue}" style="width: 80%; padding: 5px; border: 1px solid #ddd; border-radius: 5px;">`;

            // Change the edit icon to a tick icon
            editIcon.classList.remove('ri-edit-line');
            editIcon.classList.add('ri-check-line');
            editIcon.setAttribute('title', 'Confirm Change');
            editIcon.setAttribute('onclick', `confirmChange(this, '${fieldName}')`);
        }

        // Function to confirm changes
        function confirmChange(tickIcon, fieldName) {
            const fieldElement = tickIcon.previousElementSibling.querySelector('.editable');
            const inputElement = fieldElement.querySelector('input');
            const newValue = inputElement.value;

            // Replace the input field with the new value
            fieldElement.textContent = newValue;

            // Change the tick icon back to an edit icon
            tickIcon.classList.remove('ri-check-line');
            tickIcon.classList.add('ri-edit-line');
            tickIcon.setAttribute('title', 'Edit');
            tickIcon.setAttribute('onclick', 'editField(this)');

            // Send the updated value to the server via AJAX
            const studentId = document.getElementById('studentDetailsModal').getAttribute('data-student-id');
            console.log('student_id from modal:', studentId); // Log the student_id being retrieved from the modal
            const data = `student_id=${studentId}&field=${fieldName}&value=${newValue}`;
            console.log('Sending data:', data); // Log the data being sent

            fetch('update_student_details.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: data
            }).then(response => response.json()).then(data => {
                console.log('Server response:', data); // Log the server response
                if (data.success) {
                    console.log('Update successful');
                } else {
                    console.error('Update failed');
                }
            }).catch(error => {
                console.error('Error:', error);
            });
        }

    </script>
</body>

</html>